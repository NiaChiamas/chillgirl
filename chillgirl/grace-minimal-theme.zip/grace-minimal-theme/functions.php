<?php

	include_once(get_template_directory() . '/includes/theme_setup.php');
	
	include_once(get_template_directory() . '/includes/acf/acf_default.php');
	
	include_once(get_template_directory() . '/includes/tgmp/tgmp_setup.php');

	include_once(get_template_directory() . '/includes/theme_customizer.php');